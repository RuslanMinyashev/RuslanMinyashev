package ru.lesson1;

/* Задание №1
public class mainApp {
    public static void main(){

    }
}
 */

/* Задание №2
public class mainApp {
    public static void main(String[] args){
        byte a = 5;
        short b = 157;
        int c = 3000;
        long d = 48789L;
        float i = 12.22f;
        double f = 111.11;
        char e = '*';
        boolean j = true;
        String l = "My Name is Ruslan";

    }
}
*/

/* Задание №3
public class mainApp {
    public static void main(String[] args){
        float a = 4f;
        float b = 8f;
        float c = 44f;
        float d = 12f;
        float e = a * (b + (c / d));
        System.out.println ("e =" + e);
    }
}

 */
/* Задание №4
public class mainApp {
    public static void main (String [] args){
        int a = 12, b = 6;
        int d = a+b;
        System.out.println ("Значение равно: " + (d >= 10 && d <=20));
    }
}
*/

/* Задание №5
public class mainApp{
    public static void main(String[] args) {
        int a = -5;
        if (a >= 0){
             System.out.println ("Число положительное");
        }
        else if (a < 0){
            System.out.println ("Число отритательное");
        }

    }
}

 */

/* Задание №6
public class mainApp {
    public static void main(String[] args)
    {
        System.out.println(run (-3));
    }

    public static boolean run(int a)
    {
        if (a < 0) {
            return true;
        }
        else {
            return false;
        }
    }
}
*/

/* Задание №7
public class mainApp {
    public static void main(String[] args)
    {
       System.out.println("Привет " + myname ("Руслан"));
    }

    public static String myname(String name)
    {
return name;
    }
}
*/



